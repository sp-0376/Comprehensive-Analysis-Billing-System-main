/**
 * 
 */
/**
 * 
 */
module Project {
	requires java.desktop;
	requires jfreechart;
	requires java.sql;
}